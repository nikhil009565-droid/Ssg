package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.MatchFormat
import com.example.data.model.MatchStatus
import com.example.data.model.Tournament
import com.example.data.repository.TodamentRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("TODAMENT", appName)
  }

  @Test
  fun `verify super admin email and password constants`() {
    assertEquals("firefree60510@gmail.com", TodamentRepository.SUPER_ADMIN_EMAIL)
    assertEquals("danger10", TodamentRepository.SUPER_ADMIN_PASSWORD)
  }

  @Test
  fun `verify tournament format properties`() {
    assertEquals(1, MatchFormat.SOLO.teamSize)
    assertEquals(2, MatchFormat.DUO.teamSize)
    assertEquals(4, MatchFormat.SQUAD.teamSize)
    assertEquals(4, MatchFormat.CLASH_SQUAD.teamSize)
  }

  @Test
  fun `verify default app settings has telegram support link`() {
    val settings = com.example.data.model.AppSettings()
    assertTrue(settings.telegramHelpUrl.isNotEmpty())
    assertTrue(settings.telegramHelpUrl.contains("t.me"))
  }
}
