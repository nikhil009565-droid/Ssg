package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.model.MatchFormat
import com.example.data.model.MatchStatus
import com.example.data.model.RequestStatus
import com.example.data.model.TransactionType

class Converters {
  @TypeConverter
  fun fromMatchFormat(value: MatchFormat?): String = value?.name ?: MatchFormat.SOLO.name

  @TypeConverter
  fun toMatchFormat(value: String?): MatchFormat =
    try {
      MatchFormat.valueOf(value ?: MatchFormat.SOLO.name)
    } catch (_: Exception) {
      MatchFormat.SOLO
    }

  @TypeConverter
  fun fromMatchStatus(value: MatchStatus?): String = value?.name ?: MatchStatus.OPEN.name

  @TypeConverter
  fun toMatchStatus(value: String?): MatchStatus =
    try {
      MatchStatus.valueOf(value ?: MatchStatus.OPEN.name)
    } catch (_: Exception) {
      MatchStatus.OPEN
    }

  @TypeConverter
  fun fromTransactionType(value: TransactionType?): String = value?.name ?: TransactionType.DEPOSIT.name

  @TypeConverter
  fun toTransactionType(value: String?): TransactionType =
    try {
      TransactionType.valueOf(value ?: TransactionType.DEPOSIT.name)
    } catch (_: Exception) {
      TransactionType.DEPOSIT
    }

  @TypeConverter
  fun fromRequestStatus(value: RequestStatus?): String = value?.name ?: RequestStatus.PENDING.name

  @TypeConverter
  fun toRequestStatus(value: String?): RequestStatus =
    try {
      RequestStatus.valueOf(value ?: RequestStatus.PENDING.name)
    } catch (_: Exception) {
      RequestStatus.PENDING
    }
}
