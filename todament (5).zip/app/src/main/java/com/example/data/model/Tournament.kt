package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MatchFormat(val displayName: String, val teamSize: Int) {
  SOLO("Solo", 1),
  DUO("Duo", 2),
  SQUAD("Squad", 4),
  CLASH_SQUAD("Clash Squad", 4)
}

enum class MatchStatus(val displayName: String) {
  OPEN("Registration Open"),
  FULL("Full"),
  LIVE("Live"),
  COMPLETED("Completed"),
  CANCELLED("Cancelled")
}

@Entity(tableName = "tournaments")
data class Tournament(
  @PrimaryKey val id: String,
  val title: String,
  val mapName: String, // Bermuda, Purgatory, Kalahari, NexTerra
  val format: MatchFormat,
  val entryFee: Double,
  val totalPrizePool: Double,
  val firstPrize: Double,
  val secondPrize: Double,
  val thirdPrize: Double,
  val perKillBonus: Double,
  val matchDate: String, // e.g. "2026-10-25"
  val startTime: String, // e.g. "20:00"
  val registrationClosingTime: String, // e.g. "19:45"
  val matchTimestamp: Long, // Epoch ms for time-based calculations
  val totalSlots: Int,
  val filledSlots: Int = 0,
  val status: MatchStatus = MatchStatus.OPEN,
  val customRules: String = "1. Mobile devices only (No Emulators/iPads)\n2. Gun skins attributes: OFF\n3. Character skills: ON\n4. Teaming up or hacking leads to immediate ban & forfeit\n5. Join room 10 minutes prior to start time",
  val roomId: String = "",
  val roomPassword: String = "",
  val isRoomVisible: Boolean = false
)
