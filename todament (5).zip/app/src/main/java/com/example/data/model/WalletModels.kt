package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType(val displayName: String, val isCredit: Boolean) {
  DEPOSIT("UPI Deposit", true),
  WINNING("Match Prize Winnings", true),
  ENTRY_FEE("Tournament Entry Fee", false),
  REFUND("Match Refund", true),
  REFERRAL_BONUS("Referral Commission", true),
  WITHDRAWAL("UPI Withdrawal", false)
}

@Entity(tableName = "wallet_transactions")
data class WalletTransaction(
  @PrimaryKey val id: String,
  val userEmail: String,
  val type: TransactionType,
  val amount: Double,
  val title: String,
  val description: String = "",
  val referenceId: String = "", // UTR or Tournament ID or Withdrawal ID
  val timestamp: Long = System.currentTimeMillis()
)

enum class RequestStatus(val displayName: String) {
  PENDING("Pending Review"),
  APPROVED("Approved"),
  REJECTED("Rejected")
}

@Entity(tableName = "deposit_requests")
data class DepositRequest(
  @PrimaryKey val id: String,
  val userEmail: String,
  val userName: String,
  val userPhone: String,
  val amount: Double,
  val utrNumber: String,
  val screenshotUri: String = "",
  val status: RequestStatus = RequestStatus.PENDING,
  val adminComment: String = "",
  val createdAt: Long = System.currentTimeMillis(),
  val resolvedAt: Long = 0L
)

@Entity(tableName = "withdrawal_requests")
data class WithdrawalRequest(
  @PrimaryKey val id: String,
  val userEmail: String,
  val userName: String,
  val amount: Double,
  val upiId: String,
  val accountHolderName: String,
  val status: RequestStatus = RequestStatus.PENDING,
  val payoutReference: String = "",
  val rejectReason: String = "",
  val createdAt: Long = System.currentTimeMillis(),
  val resolvedAt: Long = 0L
)
