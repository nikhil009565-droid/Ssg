package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.model.AppSettings
import com.example.data.model.DepositRequest
import com.example.data.model.PromotionalBanner
import com.example.data.model.Registration
import com.example.data.model.Tournament
import com.example.data.model.User
import com.example.data.model.WalletTransaction
import com.example.data.model.WithdrawalRequest

@Database(
  entities = [
    User::class,
    Tournament::class,
    Registration::class,
    WalletTransaction::class,
    DepositRequest::class,
    WithdrawalRequest::class,
    PromotionalBanner::class,
    AppSettings::class
  ],
  version = 3,
  exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
  abstract fun userDao(): UserDao
  abstract fun tournamentDao(): TournamentDao
  abstract fun registrationDao(): RegistrationDao
  abstract fun walletDao(): WalletDao
  abstract fun appConfigDao(): AppConfigDao

  companion object {
    @Volatile
    private var INSTANCE: AppDatabase? = null

    fun getDatabase(context: Context): AppDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          AppDatabase::class.java,
          "todament_esports.db"
        )
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
