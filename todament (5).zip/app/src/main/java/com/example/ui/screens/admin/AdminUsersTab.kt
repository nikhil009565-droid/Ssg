package com.example.ui.screens.admin

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Games
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.User
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TodamentViewModel

@Composable
fun AdminUsersTab(viewModel: TodamentViewModel) {
  val context = LocalContext.current
  val allUsers by viewModel.allUsers.collectAsState()
  var searchQuery by remember { mutableStateOf("") }

  // Balance Adjustment Dialog State
  var selectedUserForAdjustment by remember { mutableStateOf<User?>(null) }
  var adjustmentAmountStr by remember { mutableStateOf("") }
  var isAddition by remember { mutableStateOf(true) }
  var adjustmentReason by remember { mutableStateOf("") }

  val filteredUsers = remember(allUsers, searchQuery) {
    if (searchQuery.isBlank()) {
      allUsers
    } else {
      val query = searchQuery.trim().lowercase()
      allUsers.filter {
        it.fullName.lowercase().contains(query) ||
            it.email.lowercase().contains(query) ||
            it.phoneNumber.lowercase().contains(query) ||
            it.freeFireUid.lowercase().contains(query) ||
            it.freeFireIgn.lowercase().contains(query) ||
            it.referralCode.lowercase().contains(query)
      }
    }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonBackground),
    contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 90.dp)
  ) {
    // Header & Summary
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = CarbonCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, EmeraldDark))),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "PLAYER MANAGEMENT",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = TextPrimary
              )
              Text(
                text = "View credentials, passwords, and manage wallet cash balances",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
              )
            }

            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(EmeraldDark)
                .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
              Text(
                text = "${allUsers.size} REGISTERED",
                color = EmeraldNeon,
                fontWeight = FontWeight.Black,
                fontSize = 11.sp
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Search Field
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by Name, Email, Phone, UID, IGN...", fontSize = 12.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = EmeraldNeon) },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldNeon,
              unfocusedBorderColor = CarbonBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_search_admin_users")
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))
    }

    if (filteredUsers.isEmpty()) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = CarbonCard),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(Icons.Default.People, contentDescription = null, tint = TextMuted, modifier = Modifier.size(40.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "No players found matching '$searchQuery'", color = TextSecondary, fontSize = 13.sp)
          }
        }
      }
    } else {
      items(filteredUsers, key = { it.email }) { user ->
        UserAdminDetailCard(
          user = user,
          onCopy = { label, text ->
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
            Toast.makeText(context, "$label copied to clipboard!", Toast.LENGTH_SHORT).show()
          },
          onAdjustBalance = {
            selectedUserForAdjustment = user
            adjustmentAmountStr = ""
            isAddition = true
            adjustmentReason = ""
          }
        )
        Spacer(modifier = Modifier.height(12.dp))
      }
    }
  }

  // Balance Adjustment Dialog
  selectedUserForAdjustment?.let { user ->
    AlertDialog(
      onDismissRequest = { selectedUserForAdjustment = null },
      containerColor = CarbonCard,
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = EmeraldNeon)
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "Adjust Player Balance", fontWeight = FontWeight.Black, color = TextPrimary, fontSize = 17.sp)
        }
      },
      text = {
        Column {
          Text(text = "Player: ${user.fullName} (${user.freeFireIgn})", fontWeight = FontWeight.Bold, color = TextPrimary)
          Text(text = "Email: ${user.email}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
          Text(
            text = "Current Balance: ₹%.2f".format(user.walletBalance),
            fontWeight = FontWeight.Black,
            color = EmeraldNeon,
            fontSize = 15.sp,
            modifier = Modifier.padding(vertical = 6.dp)
          )

          Spacer(modifier = Modifier.height(8.dp))

          // Add vs Deduct Toggle
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = { isAddition = true },
              colors = ButtonDefaults.buttonColors(
                containerColor = if (isAddition) EmeraldNeon else CarbonCardElevated,
                contentColor = if (isAddition) CarbonBackground else TextSecondary
              ),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Add (+)", fontWeight = FontWeight.Bold)
            }

            Button(
              onClick = { isAddition = false },
              colors = ButtonDefaults.buttonColors(
                containerColor = if (!isAddition) CrimsonAlert else CarbonCardElevated,
                contentColor = if (!isAddition) Color.White else TextSecondary
              ),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Deduct (-)", fontWeight = FontWeight.Bold)
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = adjustmentAmountStr,
            onValueChange = { adjustmentAmountStr = it },
            label = { Text("Amount (₹)") },
            placeholder = { Text("e.g. 100") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = if (isAddition) EmeraldNeon else CrimsonAlert,
              unfocusedBorderColor = CarbonBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_adjust_amount")
          )

          // Quick Amount Chips
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            listOf(50, 100, 250, 500).forEach { amt ->
              FilterChip(
                selected = adjustmentAmountStr == amt.toString(),
                onClick = { adjustmentAmountStr = amt.toString() },
                label = { Text("+₹$amt", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  containerColor = CarbonCardElevated,
                  labelColor = TextPrimary,
                  selectedContainerColor = EmeraldDark,
                  selectedLabelColor = EmeraldNeon
                )
              )
            }
          }

          OutlinedTextField(
            value = adjustmentReason,
            onValueChange = { adjustmentReason = it },
            label = { Text("Reason / Note for Player") },
            placeholder = { Text("e.g. Tournament reward / Manual adjustment") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldNeon,
              unfocusedBorderColor = CarbonBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_adjust_reason")
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val amount = adjustmentAmountStr.toDoubleOrNull()
            if (amount != null && amount > 0.0) {
              val delta = if (isAddition) amount else -amount
              viewModel.adjustUserBalance(user.email, delta, adjustmentReason.trim())
              selectedUserForAdjustment = null
            } else {
              Toast.makeText(context, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
            }
          },
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isAddition) EmeraldNeon else CrimsonAlert,
            contentColor = if (isAddition) CarbonBackground else Color.White
          ),
          modifier = Modifier.testTag("btn_confirm_adjust_balance")
        ) {
          Text("APPLY UPDATE", fontWeight = FontWeight.Black)
        }
      },
      dismissButton = {
        TextButton(onClick = { selectedUserForAdjustment = null }) {
          Text("Cancel", color = TextSecondary)
        }
      }
    )
  }
}

@Composable
private fun UserAdminDetailCard(
  user: User,
  onCopy: (label: String, text: String) -> Unit,
  onAdjustBalance: () -> Unit
) {
  var showPassword by remember { mutableStateOf(false) }

  Card(
    colors = CardDefaults.cardColors(containerColor = CarbonCard),
    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))),
    shape = RoundedCornerShape(14.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      // Header: Name, Role, Balance
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = user.fullName,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Black,
              color = TextPrimary
            )
            Spacer(modifier = Modifier.width(6.dp))
            if (user.isAdmin) {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(CrimsonAlert)
                  .padding(horizontal = 5.dp, vertical = 2.dp)
              ) {
                Text("ADMIN", color = Color.White, fontWeight = FontWeight.Black, fontSize = 8.sp)
              }
            } else {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(CarbonCardElevated)
                  .padding(horizontal = 5.dp, vertical = 2.dp)
              ) {
                Text("PLAYER", color = EmeraldNeon, fontWeight = FontWeight.Bold, fontSize = 8.sp)
              }
            }
          }
          Text(
            text = "IGN: ${user.freeFireIgn}",
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = EmeraldNeon
          )
        }

        // Current Balance Box
        Column(horizontalAlignment = Alignment.End) {
          Text(text = "WALLET CASH", fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold)
          Text(
            text = "₹%.2f".format(user.walletBalance),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 17.sp,
            color = if (user.walletBalance > 0) EmeraldNeon else AmberGold
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Free Fire UID & Phone Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // UID
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(CarbonCardElevated)
            .padding(10.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(text = "FREE FIRE UID", fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold)
              Text(
                text = user.freeFireUid.ifEmpty { "N/A" },
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = TextPrimary
              )
            }
            IconButton(
              onClick = { onCopy("Free Fire UID", user.freeFireUid) },
              modifier = Modifier.size(24.dp)
            ) {
              Icon(Icons.Default.ContentCopy, contentDescription = "Copy UID", tint = NeonCyan, modifier = Modifier.size(14.dp))
            }
          }
        }

        // Phone
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(CarbonCardElevated)
            .padding(10.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(text = "WHATSAPP / PHONE", fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold)
              Text(
                text = user.phoneNumber.ifEmpty { "N/A" },
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = TextPrimary
              )
            }
            IconButton(
              onClick = { onCopy("Phone", user.phoneNumber) },
              modifier = Modifier.size(24.dp)
            ) {
              Icon(Icons.Default.ContentCopy, contentDescription = "Copy Phone", tint = NeonCyan, modifier = Modifier.size(14.dp))
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Email Address
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(CarbonCardElevated)
          .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          Icon(Icons.Default.Email, contentDescription = null, tint = TextMuted, modifier = Modifier.size(13.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = user.email, fontSize = 11.sp, color = TextSecondary)
        }
        IconButton(
          onClick = { onCopy("Email", user.email) },
          modifier = Modifier.size(24.dp)
        ) {
          Icon(Icons.Default.ContentCopy, contentDescription = "Copy Email", tint = NeonCyan, modifier = Modifier.size(13.dp))
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Password Box (Specifically requested so admin can view user's password)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(CarbonCardElevated)
          .border(1.dp, CarbonBorder, RoundedCornerShape(8.dp))
          .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          Icon(Icons.Default.Lock, contentDescription = null, tint = AmberGold, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Column {
            Text(text = "ACCOUNT PASSWORD", fontSize = 9.sp, color = AmberGold, fontWeight = FontWeight.Bold)
            Text(
              text = if (showPassword) {
                user.password.ifEmpty { "(No password set)" }
              } else {
                "••••••••"
              },
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              color = TextPrimary
            )
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = { showPassword = !showPassword },
            modifier = Modifier.size(24.dp)
          ) {
            Icon(
              imageVector = if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
              contentDescription = "Toggle password",
              tint = TextMuted,
              modifier = Modifier.size(14.dp)
            )
          }
          Spacer(modifier = Modifier.width(4.dp))
          IconButton(
            onClick = { onCopy("Password", user.password) },
            modifier = Modifier.size(24.dp)
          ) {
            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Password", tint = NeonCyan, modifier = Modifier.size(14.dp))
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Referral Details
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "Ref Code: ${user.referralCode}",
          fontSize = 11.sp,
          color = TextMuted
        )
        if (user.referredByCode.isNotBlank()) {
          Text(
            text = "Referred By: ${user.referredByCode}",
            fontSize = 11.sp,
            color = NeonCyan
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Action: Adjust Balance Button
      Button(
        onClick = onAdjustBalance,
        colors = ButtonDefaults.buttonColors(containerColor = CarbonCardElevated, contentColor = EmeraldNeon),
        border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, EmeraldDark))),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("btn_adjust_balance_${user.email}")
      ) {
        Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = "ADJUST BALANCE (ADD / DEDUCT ₹)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
      }
    }
  }
}
