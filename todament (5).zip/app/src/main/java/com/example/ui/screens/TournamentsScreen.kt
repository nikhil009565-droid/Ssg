package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.MatchFormat
import com.example.data.model.MatchStatus
import com.example.data.model.Tournament
import com.example.ui.components.CopyableCodeBox
import com.example.ui.components.FormatBadge
import com.example.ui.components.MapBadge
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TodamentViewModel

@Composable
fun TournamentsScreen(
  viewModel: TodamentViewModel,
  onNavigateToWallet: () -> Unit,
  selectedTournamentFromHome: Tournament? = null
) {
  val currentUser by viewModel.currentUser.collectAsState()
  val tournaments by viewModel.tournaments.collectAsState()
  val userRegistrations by viewModel.userRegistrations.collectAsState()

  var selectedFilter by remember { mutableStateOf("All") }
  val filterCategories = listOf("All", "Solo", "Duo", "Squad", "Clash Squad")

  var detailedTournament by remember { mutableStateOf(selectedTournamentFromHome) }
  var showRegistrationDialog by remember { mutableStateOf(false) }

  val registeredTournamentIds = remember(userRegistrations) {
    userRegistrations.map { it.tournamentId }.toSet()
  }

  val displayTournaments = remember(tournaments, selectedFilter) {
    when (selectedFilter) {
      "Solo" -> tournaments.filter { it.format == MatchFormat.SOLO }
      "Duo" -> tournaments.filter { it.format == MatchFormat.DUO }
      "Squad" -> tournaments.filter { it.format == MatchFormat.SQUAD }
      "Clash Squad" -> tournaments.filter { it.format == MatchFormat.CLASH_SQUAD }
      else -> tournaments
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonBackground)
  ) {
    // Header & Filter Bar
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(CarbonSurface)
        .padding(top = 12.dp, bottom = 10.dp)
    ) {
      Text(
        text = "TOURNAMENT ARENA",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Black,
        color = TextPrimary,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(horizontal = 16.dp)
      )
      Text(
        text = "Select match, register squad, and compete for verified cash prizes",
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary,
        modifier = Modifier.padding(horizontal = 16.dp)
      )

      Spacer(modifier = Modifier.height(10.dp))

      LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(filterCategories) { category ->
          val isSelected = selectedFilter == category
          Surface(
            onClick = { selectedFilter = category },
            shape = RoundedCornerShape(20.dp),
            color = if (isSelected) EmeraldNeon else CarbonCard,
            border = if (!isSelected) CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))) else null,
            modifier = Modifier.testTag("tourn_filter_$category")
          ) {
            Text(
              text = category,
              modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp),
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = if (isSelected) CarbonBackground else TextSecondary,
              fontSize = 12.sp
            )
          }
        }
      }
    }

    // Match List (STRICTLY WITHOUT THUMBNAILS)
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(top = 8.dp, bottom = 90.dp)
    ) {
      if (displayTournaments.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(40.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "No matches found under $selectedFilter.",
              color = TextMuted,
              style = MaterialTheme.typography.bodyMedium
            )
          }
        }
      } else {
        items(displayTournaments) { tournament ->
          val isUserRegistered = registeredTournamentIds.contains(tournament.id)
          TournamentListCard(
            tournament = tournament,
            isUserRegistered = isUserRegistered,
            onCardClick = { detailedTournament = tournament }
          )
        }
      }
    }
  }

  // TOURNAMENT DETAILS & ROOM CREDENTIALS MODAL
  detailedTournament?.let { tourn ->
    val isRegistered = registeredTournamentIds.contains(tourn.id)

    TournamentDetailsDialog(
      tournament = tourn,
      isRegistered = isRegistered,
      userBalance = currentUser?.walletBalance ?: 0.0,
      onDismiss = { detailedTournament = null },
      onJoinNow = {
        showRegistrationDialog = true
      },
      onDeposit = onNavigateToWallet
    )
  }

  // SQUAD REGISTRATION MODAL
  if (showRegistrationDialog && detailedTournament != null) {
    val tourn = detailedTournament!!
    MatchRegistrationDialog(
      tournament = tourn,
      currentUserIgn = currentUser?.freeFireIgn ?: "",
      currentUserUid = currentUser?.freeFireUid ?: "",
      userBalance = currentUser?.walletBalance ?: 0.0,
      onDismiss = { showRegistrationDialog = false },
      onSubmitRegistration = { teamName, teammates ->
        viewModel.registerForTournament(
          tournamentId = tourn.id,
          teamName = teamName,
          teammates = teammates,
          onSuccess = {
            showRegistrationDialog = false
            detailedTournament = null
          }
        )
      },
      onDeposit = onNavigateToWallet
    )
  }
}

@Composable
fun TournamentListCard(
  tournament: Tournament,
  isUserRegistered: Boolean,
  onCardClick: () -> Unit
) {
  Card(
    onClick = onCardClick,
    colors = CardDefaults.cardColors(containerColor = CarbonCard),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.horizontalGradient(
        if (isUserRegistered) listOf(EmeraldDark, EmeraldNeon)
        else listOf(CarbonBorder, CarbonBorder)
      )
    ),
    shape = RoundedCornerShape(14.dp),
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 6.dp)
      .testTag("tournament_card_${tournament.id}")
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      // Row 1: Badges + Registered Tag
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          FormatBadge(format = tournament.format)
          MapBadge(mapName = tournament.mapName)
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          if (isUserRegistered) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(EmeraldDark.copy(alpha = 0.25f))
                .border(1.dp, EmeraldNeon, RoundedCornerShape(6.dp))
                .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldNeon, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "JOINED",
                  style = MaterialTheme.typography.labelSmall,
                  color = EmeraldNeon,
                  fontWeight = FontWeight.Bold,
                  fontSize = 10.sp
                )
              }
            }
            Spacer(modifier = Modifier.width(6.dp))
          }
          StatusBadge(status = tournament.status)
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Match Title & Schedule
      Text(
        text = tournament.title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )

      Text(
        text = "${tournament.matchDate} at ${tournament.startTime} (Closes ${tournament.registrationClosingTime})",
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary,
        fontSize = 12.sp
      )

      Spacer(modifier = Modifier.height(12.dp))

      // Financial Matrix
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(CarbonCardElevated)
          .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text(text = "PRIZE POOL", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
          Text(
            text = "₹${tournament.totalPrizePool.toInt()}",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = AmberGold
          )
        }
        Column {
          Text(text = "1ST PRIZE", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
          Text(
            text = "₹${tournament.firstPrize.toInt()}",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = EmeraldNeon
          )
        }
        Column {
          Text(text = "PER KILL", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
          Text(
            text = "₹${tournament.perKillBonus.toInt()}",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = NeonCyan
          )
        }
        Column {
          Text(text = "ENTRY FEE", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
          Text(
            text = "₹${tournament.entryFee.toInt()}",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = TextPrimary
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Bottom Row: Slots info & tap to view CTA
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Slots: ${tournament.filledSlots}/${tournament.totalSlots} Filled",
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary,
          fontSize = 12.sp
        )

        Text(
          text = if (isUserRegistered) "View Room Credentials →" else "Tap for Details & Rules →",
          color = if (isUserRegistered) EmeraldNeon else NeonCyan,
          fontWeight = FontWeight.Bold,
          fontSize = 12.sp
        )
      }
    }
  }
}

@Composable
fun TournamentDetailsDialog(
  tournament: Tournament,
  isRegistered: Boolean,
  userBalance: Double,
  onDismiss: () -> Unit,
  onJoinNow: () -> Unit,
  onDeposit: () -> Unit
) {
  val scrollState = rememberScrollState()

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = CarbonCardElevated,
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, EmeraldDark))),
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 16.dp)
    ) {
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(scrollState)
      ) {
        // Modal Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FormatBadge(format = tournament.format)
            MapBadge(mapName = tournament.mapName)
          }
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = tournament.title,
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Black,
          color = TextPrimary
        )

        Text(
          text = "Date: ${tournament.matchDate} • Start: ${tournament.startTime}",
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary
        )

        Spacer(modifier = Modifier.height(14.dp))

        // ROOM CREDENTIALS SECTION (AUTO-HIDDEN UNTIL REVEALED)
        Card(
          colors = CardDefaults.cardColors(containerColor = CarbonCard),
          border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(
              if (isRegistered && (tournament.isRoomVisible || tournament.roomId.isNotBlank())) listOf(EmeraldDark, EmeraldNeon)
              else listOf(CarbonBorder, CarbonBorder)
            )
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = if (isRegistered && tournament.isRoomVisible) EmeraldNeon else AmberGold,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "CUSTOM ROOM CREDENTIALS",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (isRegistered && tournament.isRoomVisible) EmeraldNeon else AmberGold
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (!isRegistered) {
              Text(
                text = "Room ID and Password are kept strictly hidden and visible only to confirmed registered players.",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted
              )
            } else if (!tournament.isRoomVisible && tournament.roomId.isBlank()) {
              Text(
                text = "Room details will automatically unlock 15 minutes prior to match start time. Check back soon!",
                style = MaterialTheme.typography.bodySmall,
                color = NeonCyan
              )
            } else {
              // Registered and revealed!
              CopyableCodeBox(
                label = "ROOM ID",
                value = tournament.roomId.ifBlank { "998241" }
              )
              Spacer(modifier = Modifier.height(6.dp))
              CopyableCodeBox(
                label = "ROOM PASSWORD",
                value = tournament.roomPassword.ifBlank { "ffwin" }
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // PRIZE DISTRIBUTION BREAKDOWN
        Text(text = "PRIZE DISTRIBUTION", style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CarbonCard)
            .padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column {
            Text(text = "1st Place", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            Text(text = "₹${tournament.firstPrize.toInt()}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = EmeraldNeon)
          }
          Column {
            Text(text = "2nd Place", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            Text(text = "₹${tournament.secondPrize.toInt()}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AmberGold)
          }
          Column {
            Text(text = "3rd Place", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            Text(text = "₹${tournament.thirdPrize.toInt()}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = TextPrimary)
          }
          Column {
            Text(text = "Per Kill", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            Text(text = "₹${tournament.perKillBonus.toInt()}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = NeonCyan)
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // RULES LIST
        Text(text = "CUSTOM RULES & FAIR PLAY", style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Spacer(modifier = Modifier.height(6.dp))
        Card(
          colors = CardDefaults.cardColors(containerColor = CarbonCard),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = tournament.customRules,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            modifier = Modifier.padding(12.dp),
            lineHeight = 18.sp
          )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // ACTION BUTTONS
        if (isRegistered) {
          Button(
            onClick = onDismiss,
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("YOU ARE REGISTERED • READY FOR BATTLE")
          }
        } else if (tournament.status != MatchStatus.OPEN) {
          Button(
            onClick = onDismiss,
            enabled = false,
            colors = ButtonDefaults.buttonColors(disabledContainerColor = CarbonBorder),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(text = tournament.status.displayName.uppercase(), color = TextMuted)
          }
        } else {
          // Check balance
          if (userBalance < tournament.entryFee) {
            Column {
              Text(
                text = "Wallet Balance: ₹${userBalance.toInt()} (Need ₹${tournament.entryFee.toInt()})",
                color = CrimsonAlert,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold
              )
              Spacer(modifier = Modifier.height(6.dp))
              Button(
                onClick = {
                  onDismiss()
                  onDeposit()
                },
                colors = ButtonDefaults.buttonColors(containerColor = AmberGold, contentColor = CarbonBackground),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("btn_insufficient_deposit")
              ) {
                Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("ADD MONEY VIA UPI (NEED ₹${(tournament.entryFee - userBalance).toInt()})", fontWeight = FontWeight.Bold)
              }
            }
          } else {
            Button(
              onClick = {
                onDismiss()
                onJoinNow()
              },
              colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("btn_modal_join_now")
            ) {
              Text(text = "JOIN MATCH (ENTRY: ₹${tournament.entryFee.toInt()})", fontWeight = FontWeight.Black)
            }
          }
        }
      }
    }
  }
}

@Composable
fun MatchRegistrationDialog(
  tournament: Tournament,
  currentUserIgn: String,
  currentUserUid: String,
  userBalance: Double,
  onDismiss: () -> Unit,
  onSubmitRegistration: (String, List<Pair<String, String>>) -> Unit,
  onDeposit: () -> Unit
) {
  var teamName by remember { mutableStateOf("") }
  val neededTeammates = when (tournament.format) {
    MatchFormat.SOLO -> 0
    MatchFormat.DUO -> 1
    MatchFormat.SQUAD, MatchFormat.CLASH_SQUAD -> 3
  }

  // Teammates state (IGN, UID)
  val teammateNames = remember { mutableStateListOf<String>().apply { repeat(neededTeammates) { add("") } } }
  val teammateUids = remember { mutableStateListOf<String>().apply { repeat(neededTeammates) { add("") } } }

  val scrollState = rememberScrollState()

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = CarbonCardElevated,
    title = {
      Column {
        Text(
          text = "Join ${tournament.format.displayName} Scrim",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Black,
          color = TextPrimary
        )
        Text(
          text = "Entry fee ₹${tournament.entryFee.toInt()} will be deducted from your wallet",
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary
        )
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(scrollState)
      ) {
        // Player 1 (Logged in user)
        Card(
          colors = CardDefaults.cardColors(containerColor = CarbonCard),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(text = "Captain / Slot Owner", style = MaterialTheme.typography.labelSmall, color = EmeraldNeon)
            Text(text = "IGN: $currentUserIgn • UID: $currentUserUid", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (neededTeammates > 0) {
          OutlinedTextField(
            value = teamName,
            onValueChange = { teamName = it },
            label = { Text("Team Name") },
            placeholder = { Text("e.g. Clan Galaxy") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldNeon,
              unfocusedBorderColor = CarbonBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_team_name")
          )

          Spacer(modifier = Modifier.height(12.dp))
          Text(text = "Teammate Details (Mandatory)", style = MaterialTheme.typography.labelSmall, color = NeonCyan)
          Spacer(modifier = Modifier.height(6.dp))

          repeat(neededTeammates) { idx ->
            Card(
              colors = CardDefaults.cardColors(containerColor = CarbonCard),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text(text = "Teammate #${idx + 2}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  OutlinedTextField(
                    value = teammateNames[idx],
                    onValueChange = { teammateNames[idx] = it },
                    label = { Text("IGN") },
                    colors = OutlinedTextFieldDefaults.colors(
                      focusedBorderColor = EmeraldNeon,
                      unfocusedBorderColor = CarbonBorder,
                      focusedTextColor = TextPrimary,
                      unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                      .weight(1f)
                      .testTag("input_teammate_ign_$idx")
                  )
                  OutlinedTextField(
                    value = teammateUids[idx],
                    onValueChange = { teammateUids[idx] = it },
                    label = { Text("FF UID") },
                    colors = OutlinedTextFieldDefaults.colors(
                      focusedBorderColor = EmeraldNeon,
                      unfocusedBorderColor = CarbonBorder,
                      focusedTextColor = TextPrimary,
                      unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                      .weight(1f)
                      .testTag("input_teammate_uid_$idx")
                  )
                }
              }
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val teammatesList = mutableListOf<Pair<String, String>>()
          repeat(neededTeammates) { i ->
            teammatesList.add(teammateNames[i] to teammateUids[i])
          }
          onSubmitRegistration(teamName, teammatesList)
        },
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
        modifier = Modifier.testTag("btn_confirm_registration")
      ) {
        Text("CONFIRM & PAY ₹${tournament.entryFee.toInt()}", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("CANCEL", color = TextSecondary)
      }
    }
  )
}
