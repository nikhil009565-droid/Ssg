package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Games
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.TodamentRepository
import com.example.ui.components.CopyableCodeBox
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TodamentViewModel

@Composable
fun ProfileScreen(
  viewModel: TodamentViewModel,
  onNavigateToAdmin: () -> Unit,
  onNavigateToWallet: () -> Unit,
  onLogout: () -> Unit
) {
  val context = LocalContext.current
  val currentUser by viewModel.currentUser.collectAsState()
  val appSettings by viewModel.appSettings.collectAsState()
  val isAdmin = currentUser?.isAdmin == true || currentUser?.email?.equals(TodamentRepository.SUPER_ADMIN_EMAIL, ignoreCase = true) == true

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonBackground)
  ) {
    // Header
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(CarbonSurface)
        .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
      Text(
        text = "GAMER IDENTITY",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Black,
        color = TextPrimary,
        letterSpacing = 1.sp
      )
      Text(
        text = "Your verified Free Fire esports credentials and account settings",
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary
      )
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 90.dp)
    ) {
      // 1. FREE FIRE PLAYER BADGE CARD
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = CarbonCard),
          border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, EmeraldDark))),
          shape = RoundedCornerShape(18.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(56.dp)
                  .clip(RoundedCornerShape(14.dp))
                  .background(Brush.linearGradient(listOf(EmeraldNeon, NeonCyan)))
                  .padding(2.dp),
                contentAlignment = Alignment.Center
              ) {
                Box(
                  modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(12.dp))
                    .background(CarbonBackground),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = (currentUser?.freeFireIgn ?: "G").take(2).uppercase(),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp,
                    color = EmeraldNeon
                  )
                }
              }

              Spacer(modifier = Modifier.width(14.dp))

              Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = currentUser?.freeFireIgn ?: "Gamer",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = TextPrimary
                  )
                  if (isAdmin) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(CrimsonAlert)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                      Text(
                        text = "SUPER ADMIN",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 9.sp
                      )
                    }
                  }
                }
                Text(
                  text = currentUser?.fullName ?: "",
                  style = MaterialTheme.typography.bodyMedium,
                  color = TextSecondary
                )
                Text(
                  text = currentUser?.email ?: "",
                  style = MaterialTheme.typography.bodySmall,
                  color = TextMuted,
                  fontSize = 11.sp
                )
              }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Free Fire Credentials Row
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(CarbonCardElevated)
                .padding(14.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(text = "FREE FIRE NUMERIC UID", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
                Text(
                  text = currentUser?.freeFireUid ?: "N/A",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 17.sp,
                  color = EmeraldNeon
                )
              }

              IconButton(
                onClick = {
                  val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                  val clip = ClipData.newPlainText("Free Fire UID", currentUser?.freeFireUid ?: "")
                  clipboard.setPrimaryClip(clip)
                  Toast.makeText(context, "UID Copied to clipboard!", Toast.LENGTH_SHORT).show()
                }
              ) {
                Icon(Icons.Default.ContentCopy, contentDescription = "Copy UID", tint = NeonCyan, modifier = Modifier.size(18.dp))
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            CopyableCodeBox(
              label = "MY REFERRAL CODE",
              value = currentUser?.referralCode ?: "TODA-1001",
              testTag = "profile_ref_code"
            )
          }
        }
      }

      // 2. ADMIN SUITE CTA (IF ADMIN)
      if (isAdmin) {
        item {
          Spacer(modifier = Modifier.height(14.dp))
          Button(
            onClick = onNavigateToAdmin,
            colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert, contentColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(50.dp)
              .testTag("btn_launch_admin_suite")
          ) {
            Icon(Icons.Default.AdminPanelSettings, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "LAUNCH SUPER ADMIN MANAGEMENT SUITE", fontWeight = FontWeight.Black, fontSize = 13.sp)
          }
        }
      }



      // 3. HELP & TELEGRAM SUPPORT CHANNEL
      item {
        Spacer(modifier = Modifier.height(14.dp))
        Card(
          colors = CardDefaults.cardColors(containerColor = CarbonCard),
          border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, NeonCyan))),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.fillMaxWidth()
            ) {
              Box(
                modifier = Modifier
                  .size(42.dp)
                  .clip(CircleShape)
                  .background(NeonCyan.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Send, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = "HELP & TELEGRAM CHANNEL",
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Black,
                  color = TextPrimary
                )
                Text(
                  text = "24/7 Match assistance & custom room support",
                  style = MaterialTheme.typography.bodySmall,
                  color = TextSecondary,
                  fontSize = 11.sp
                )
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
              text = "Need help joining custom rooms, reporting scores, or managing deposit/withdrawal issues? Join our official Telegram channel for instant operator support.",
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary,
              lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            Button(
              onClick = {
                val url = appSettings.telegramHelpUrl.ifBlank { "https://t.me/todament_support" }
                try {
                  val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                  context.startActivity(intent)
                } catch (e: Exception) {
                  Toast.makeText(context, "Could not open browser or Telegram", Toast.LENGTH_SHORT).show()
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = CarbonBackground),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("btn_join_telegram_channel")
            ) {
              Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "JOIN TELEGRAM CHANNEL",
                fontWeight = FontWeight.Black,
                fontSize = 12.sp,
                letterSpacing = 0.5.sp
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedButton(
              onClick = {
                val url = appSettings.telegramHelpUrl.ifBlank { "https://t.me/todament_support" }
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("Telegram Link", url)
                clipboard.setPrimaryClip(clip)
                Toast.makeText(context, "Telegram link copied to clipboard!", Toast.LENGTH_SHORT).show()
              },
              colors = ButtonDefaults.outlinedButtonColors(containerColor = CarbonCardElevated),
              border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("btn_copy_telegram_link")
            ) {
              Icon(Icons.Default.ContentCopy, contentDescription = null, tint = TextMuted, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Copy Telegram Link",
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }

      // 4. LOGOUT
      item {
        Spacer(modifier = Modifier.height(20.dp))
        Button(
          onClick = {
            viewModel.logout()
            onLogout()
          },
          colors = ButtonDefaults.buttonColors(containerColor = CarbonCardElevated, contentColor = CrimsonAlert),
          border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("btn_logout")
        ) {
          Icon(Icons.Default.ExitToApp, contentDescription = null, tint = CrimsonAlert)
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "LOG OUT OF TODAMENT", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(14.dp))
        Text(
          text = "TODAMENT v1.0 • Native Android Free Fire Esports Engine",
          style = MaterialTheme.typography.bodySmall,
          color = TextMuted,
          fontSize = 11.sp,
          textAlign = androidx.compose.ui.text.style.TextAlign.Center,
          modifier = Modifier.fillMaxWidth()
        )
      }
    }
  }
}
