package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CarbonBackground = Color(0xFF08090E)
val CarbonSurface = Color(0xFF0E1118)
val CarbonCard = Color(0xFF151A26)
val CarbonCardElevated = Color(0xFF1C2333)
val CarbonBorder = Color(0xFF222B3D)

val EmeraldNeon = Color(0xFF00FF66)
val EmeraldDark = Color(0xFF00993D)
val EmeraldGlow = Color(0x3300FF66)

val NeonCyan = Color(0xFF00E5FF)
val AmberGold = Color(0xFFFFB800)
val CrimsonAlert = Color(0xFFFF3366)

val TextPrimary = Color(0xFFF3F6FC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
