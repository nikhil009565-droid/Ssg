package com.example.ui.screens.admin

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DepositRequest
import com.example.data.model.RequestStatus
import com.example.data.model.WithdrawalRequest
import com.example.ui.components.CopyableCodeBox
import com.example.ui.components.ZoomableImageDialog
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TodamentViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminPaymentsTab(viewModel: TodamentViewModel) {
  var selectedSubTab by remember { mutableIntStateOf(0) } // 0: Deposits, 1: Withdrawals
  val allDeposits by viewModel.allDepositRequests.collectAsState()
  val allWithdrawals by viewModel.allWithdrawalRequests.collectAsState()

  var previewScreenshotUrl by remember { mutableStateOf<String?>(null) }
  var depositToReject by remember { mutableStateOf<DepositRequest?>(null) }
  var withdrawalToPay by remember { mutableStateOf<WithdrawalRequest?>(null) }
  var withdrawalToReject by remember { mutableStateOf<WithdrawalRequest?>(null) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonBackground)
  ) {
    // Sub-Tabs
    TabRow(
      selectedTabIndex = selectedSubTab,
      containerColor = CarbonCard,
      contentColor = EmeraldNeon,
      indicator = { tabPositions ->
        TabRowDefaults.SecondaryIndicator(
          modifier = Modifier.tabIndicatorOffset(tabPositions[selectedSubTab]),
          color = EmeraldNeon,
          height = 3.dp
        )
      },
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp)
        .clip(RoundedCornerShape(10.dp))
        .border(1.dp, CarbonBorder, RoundedCornerShape(10.dp))
    ) {
      val pendingDepositsCount = allDeposits.count { it.status == RequestStatus.PENDING }
      val pendingWithdrawalsCount = allWithdrawals.count { it.status == RequestStatus.PENDING }

      Tab(
        selected = selectedSubTab == 0,
        onClick = { selectedSubTab = 0 },
        text = {
          Text(
            text = "DEPOSITS ($pendingDepositsCount PENDING)",
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = if (selectedSubTab == 0) EmeraldNeon else TextSecondary
          )
        },
        modifier = Modifier.testTag("admin_tab_deposits")
      )
      Tab(
        selected = selectedSubTab == 1,
        onClick = { selectedSubTab = 1 },
        text = {
          Text(
            text = "WITHDRAWALS ($pendingWithdrawalsCount PENDING)",
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = if (selectedSubTab == 1) EmeraldNeon else TextSecondary
          )
        },
        modifier = Modifier.testTag("admin_tab_withdrawals")
      )
    }

    if (selectedSubTab == 0) {
      // --- DEPOSITS LIST ---
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 90.dp)
      ) {
        if (allDeposits.isEmpty()) {
          item {
            Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
              Text("No deposit requests found", color = TextMuted)
            }
          }
        } else {
          items(allDeposits) { req ->
            AdminDepositItemCard(
              request = req,
              onViewScreenshot = { previewScreenshotUrl = req.screenshotUri },
              onApprove = { viewModel.approveDeposit(req.id) },
              onReject = { depositToReject = req }
            )
          }
        }
      }
    } else {
      // --- WITHDRAWALS LIST ---
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 90.dp)
      ) {
        if (allWithdrawals.isEmpty()) {
          item {
            Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
              Text("No withdrawal requests found", color = TextMuted)
            }
          }
        } else {
          items(allWithdrawals) { req ->
            AdminWithdrawalItemCard(
              request = req,
              onMarkPaid = { withdrawalToPay = req },
              onReject = { withdrawalToReject = req }
            )
          }
        }
      }
    }
  }

  // Screenshot Zoom Modal
  previewScreenshotUrl?.let { url ->
    ZoomableImageDialog(
      imageUrl = url,
      title = "UPI Payment Proof Inspection",
      onDismiss = { previewScreenshotUrl = null }
    )
  }

  // Reject Deposit Dialog
  depositToReject?.let { req ->
    var rejectReason by remember { mutableStateOf("Invalid or unverified UTR reference number") }
    AlertDialog(
      onDismissRequest = { depositToReject = null },
      containerColor = CarbonCardElevated,
      title = { Text("Reject Deposit Request?", fontWeight = FontWeight.Bold, color = CrimsonAlert) },
      text = {
        Column {
          Text("Enter reason for rejection:", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = rejectReason,
            onValueChange = { rejectReason = it },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.rejectDeposit(req.id, rejectReason)
            depositToReject = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert, contentColor = Color.White)
        ) {
          Text("REJECT DEPOSIT", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { depositToReject = null }) { Text("CANCEL", color = TextSecondary) }
      }
    )
  }

  // Mark Withdrawal Paid Dialog
  withdrawalToPay?.let { req ->
    var payoutRef by remember { mutableStateOf("IMPS${System.currentTimeMillis().toString().takeLast(8)}") }
    AlertDialog(
      onDismissRequest = { withdrawalToPay = null },
      containerColor = CarbonCardElevated,
      title = { Text("Mark Withdrawal as Paid", fontWeight = FontWeight.Black, color = EmeraldNeon) },
      text = {
        Column {
          Text("Send ₹${req.amount.toInt()} to UPI ID: ${req.upiId} (${req.accountHolderName})", color = TextPrimary)
          Spacer(modifier = Modifier.height(10.dp))
          OutlinedTextField(
            value = payoutRef,
            onValueChange = { payoutRef = it },
            label = { Text("Bank Payout Reference No.") },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.markWithdrawalPaid(req.id, payoutRef)
            withdrawalToPay = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground)
        ) {
          Text("CONFIRM DISPATCHED", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { withdrawalToPay = null }) { Text("CANCEL", color = TextSecondary) }
      }
    )
  }

  // Reject Withdrawal Dialog
  withdrawalToReject?.let { req ->
    var rejectReason by remember { mutableStateOf("Incorrect UPI ID or Account Name mismatch") }
    AlertDialog(
      onDismissRequest = { withdrawalToReject = null },
      containerColor = CarbonCardElevated,
      title = { Text("Reject & Auto-Refund Withdrawal?", fontWeight = FontWeight.Bold, color = CrimsonAlert) },
      text = {
        Column {
          Text("Rejecting will automatically return ₹${req.amount.toInt()} from reserved funds back to user's wallet.", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = rejectReason,
            onValueChange = { rejectReason = it },
            label = { Text("Reason") },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.rejectWithdrawal(req.id, rejectReason)
            withdrawalToReject = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert, contentColor = Color.White)
        ) {
          Text("REJECT & REFUND", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { withdrawalToReject = null }) { Text("CANCEL", color = TextSecondary) }
      }
    )
  }
}

@Composable
fun AdminDepositItemCard(
  request: DepositRequest,
  onViewScreenshot: () -> Unit,
  onApprove: () -> Unit,
  onReject: () -> Unit
) {
  val dateStr = remember(request.createdAt) {
    SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(request.createdAt))
  }

  Card(
    colors = CardDefaults.cardColors(containerColor = CarbonCard),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.horizontalGradient(
        when (request.status) {
          RequestStatus.PENDING -> listOf(AmberGold, AmberGold)
          RequestStatus.APPROVED -> listOf(EmeraldDark, EmeraldNeon)
          RequestStatus.REJECTED -> listOf(CrimsonAlert, CrimsonAlert)
        }
      )
    ),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 5.dp)
      .testTag("admin_deposit_${request.id}")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = request.userName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
          Text(text = "${request.userEmail} • Phone: ${request.userPhone}", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
        }
        Text(
          text = "₹${request.amount.toInt()}",
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Black,
          fontSize = 20.sp,
          color = EmeraldNeon
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // UTR Reference Box
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(CarbonCardElevated)
          .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "12-DIGIT UTR NUMBER", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
          Text(text = request.utrNumber, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AmberGold, fontSize = 14.sp)
        }
        Text(text = dateStr, style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 10.sp)
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Actions / Status
      if (request.status == RequestStatus.PENDING) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          if (request.screenshotUri.isNotBlank()) {
            OutlinedButton(
              onClick = onViewScreenshot,
              colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.Default.ZoomIn, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Screenshot", fontSize = 11.sp)
            }
          }

          Button(
            onClick = onApprove,
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
              .weight(1f)
              .testTag("btn_approve_deposit_${request.id}")
          ) {
            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("APPROVE", fontWeight = FontWeight.Bold, fontSize = 11.sp)
          }

          Button(
            onClick = onReject,
            colors = ButtonDefaults.buttonColors(containerColor = CarbonCardElevated, contentColor = CrimsonAlert),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(0.9f)
          ) {
            Text("REJECT", fontWeight = FontWeight.Bold, fontSize = 11.sp)
          }
        }
      } else {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Status: ${request.status.displayName.uppercase()}",
            fontWeight = FontWeight.Bold,
            color = if (request.status == RequestStatus.APPROVED) EmeraldNeon else CrimsonAlert,
            fontSize = 12.sp
          )
          if (request.screenshotUri.isNotBlank()) {
            Text(
              text = "Inspect Screenshot →",
              color = NeonCyan,
              style = MaterialTheme.typography.bodySmall,
              fontSize = 11.sp,
              modifier = Modifier.clickable { onViewScreenshot() }
            )
          }
        }
      }
    }
  }
}

@Composable
fun AdminWithdrawalItemCard(
  request: WithdrawalRequest,
  onMarkPaid: () -> Unit,
  onReject: () -> Unit
) {
  val dateStr = remember(request.createdAt) {
    SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(request.createdAt))
  }

  Card(
    colors = CardDefaults.cardColors(containerColor = CarbonCard),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.horizontalGradient(
        when (request.status) {
          RequestStatus.PENDING -> listOf(AmberGold, AmberGold)
          RequestStatus.APPROVED -> listOf(EmeraldDark, EmeraldNeon)
          RequestStatus.REJECTED -> listOf(CrimsonAlert, CrimsonAlert)
        }
      )
    ),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 5.dp)
      .testTag("admin_withdrawal_${request.id}")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = request.userName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
          Text(text = request.userEmail, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
        }
        Text(
          text = "₹${request.amount.toInt()}",
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Black,
          fontSize = 20.sp,
          color = AmberGold
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Bank & UPI Target Info
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(CarbonCardElevated)
          .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text(text = "DESTINATION UPI ID", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
          Text(text = request.upiId, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = NeonCyan, fontSize = 13.sp)
          Text(text = "Name: ${request.accountHolderName}", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
        }
        Text(text = dateStr, style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 10.sp)
      }

      Spacer(modifier = Modifier.height(10.dp))

      if (request.status == RequestStatus.PENDING) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = onMarkPaid,
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
              .weight(1f)
              .testTag("btn_approve_payout_${request.id}")
          ) {
            Text("MARK PAID (SEND UPI)", fontWeight = FontWeight.Bold, fontSize = 11.sp)
          }

          Button(
            onClick = onReject,
            colors = ButtonDefaults.buttonColors(containerColor = CarbonCardElevated, contentColor = CrimsonAlert),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(0.7f)
          ) {
            Text("REJECT & REFUND", fontWeight = FontWeight.Bold, fontSize = 11.sp)
          }
        }
      } else {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "Status: ${request.status.displayName.uppercase()}",
            fontWeight = FontWeight.Bold,
            color = if (request.status == RequestStatus.APPROVED) EmeraldNeon else CrimsonAlert,
            fontSize = 12.sp
          )
          if (request.payoutReference.isNotBlank()) {
            Text(text = "Ref: ${request.payoutReference}", fontFamily = FontFamily.Monospace, color = TextMuted, fontSize = 11.sp)
          }
        }
      }
    }
  }
}
