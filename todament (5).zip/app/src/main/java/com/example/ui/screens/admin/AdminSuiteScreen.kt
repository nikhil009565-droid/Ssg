package com.example.ui.screens.admin

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.TodamentRepository
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TodamentViewModel

@Composable
fun AdminSuiteScreen(
  viewModel: TodamentViewModel,
  onNavigateBack: () -> Unit
) {
  BackHandler { onNavigateBack() }

  val currentUser by viewModel.currentUser.collectAsState()
  val isAuthorized = currentUser?.email?.trim()?.equals(TodamentRepository.SUPER_ADMIN_EMAIL, ignoreCase = true) == true

  if (!isAuthorized) {
    // ACCESS DENIED SCREEN
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(CarbonBackground)
        .padding(24.dp),
      contentAlignment = Alignment.Center
    ) {
      Card(
        colors = CardDefaults.cardColors(containerColor = CarbonCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CrimsonAlert, CrimsonAlert))),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(24.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Icon(Icons.Default.Security, contentDescription = null, tint = CrimsonAlert, modifier = Modifier.size(48.dp))
          Spacer(modifier = Modifier.height(14.dp))
          Text(text = "UNAUTHORIZED ACCESS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = CrimsonAlert)
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "The Admin Management Suite is strictly restricted to '${TodamentRepository.SUPER_ADMIN_EMAIL}'. Current user is not authorized.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
          )
          Spacer(modifier = Modifier.height(18.dp))

          Button(
            onClick = {
              viewModel.switchUser(TodamentRepository.SUPER_ADMIN_EMAIL)
            },
            colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert, contentColor = Color.White),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("LOG IN AS SUPER ADMIN OPERATOR", fontWeight = FontWeight.Bold)
          }

          Spacer(modifier = Modifier.height(8.dp))

          Button(
            onClick = onNavigateBack,
            colors = ButtonDefaults.buttonColors(containerColor = CarbonCardElevated),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("Return to Player Arena", color = TextSecondary)
          }
        }
      }
    }
    return
  }

  // AUTHORIZED ADMIN SUITE
  var selectedTab by remember { mutableIntStateOf(0) }
  val adminTabs = listOf(
    "Dashboard" to Icons.Default.Dashboard,
    "Matches" to Icons.Default.SportsEsports,
    "Results & Prizes" to Icons.Default.EmojiEvents,
    "Deposits & Payouts" to Icons.Default.Payments,
    "Players & Balances" to Icons.Default.People,
    "Settings & Backup" to Icons.Default.Settings
  )

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonBackground)
  ) {
    // Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(CarbonSurface)
        .padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(onClick = onNavigateBack) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
      }
      Spacer(modifier = Modifier.width(6.dp))
      Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "TODAMENT SUPER ADMIN",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black,
            color = TextPrimary,
            letterSpacing = 0.5.sp
          )
          Spacer(modifier = Modifier.width(8.dp))
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(CrimsonAlert)
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text("OPERATOR", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
          }
        }
        Text(
          text = TodamentRepository.SUPER_ADMIN_EMAIL,
          style = MaterialTheme.typography.bodySmall,
          color = EmeraldNeon,
          fontSize = 11.sp
        )
      }
    }

    // Scrollable Tab Row
    ScrollableTabRow(
      selectedTabIndex = selectedTab,
      containerColor = CarbonCard,
      contentColor = EmeraldNeon,
      edgePadding = 12.dp,
      indicator = { tabPositions ->
        TabRowDefaults.SecondaryIndicator(
          modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
          color = EmeraldNeon,
          height = 3.dp
        )
      },
      modifier = Modifier.fillMaxWidth()
    ) {
      adminTabs.forEachIndexed { index, (label, icon) ->
        val isSelected = selectedTab == index
        Tab(
          selected = isSelected,
          onClick = { selectedTab = index },
          text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) EmeraldNeon else TextMuted,
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = label.uppercase(),
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = if (isSelected) EmeraldNeon else TextSecondary
              )
            }
          },
          modifier = Modifier.testTag("admin_suite_tab_$index")
        )
      }
    }

    // Tab Contents
    when (selectedTab) {
      0 -> AdminDashboardTab(viewModel = viewModel)
      1 -> AdminMatchesTab(viewModel = viewModel)
      2 -> AdminResultsTab(viewModel = viewModel)
      3 -> AdminPaymentsTab(viewModel = viewModel)
      4 -> AdminUsersTab(viewModel = viewModel)
      5 -> AdminSettingsBackupTab(viewModel = viewModel)
    }
  }
}
