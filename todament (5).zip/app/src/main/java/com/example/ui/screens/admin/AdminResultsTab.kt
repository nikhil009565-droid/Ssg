package com.example.ui.screens.admin

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MatchStatus
import com.example.data.model.Registration
import com.example.data.model.Tournament
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TodamentViewModel

@Composable
fun AdminResultsTab(viewModel: TodamentViewModel) {
  val tournaments by viewModel.tournaments.collectAsState()
  var selectedTournament by remember { mutableStateOf<Tournament?>(null) }
  val context = LocalContext.current

  // Filter tournaments that are not cancelled
  val activeTournaments = remember(tournaments) {
    tournaments.filter { it.status != MatchStatus.CANCELLED }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonBackground)
  ) {
    if (selectedTournament == null) {
      // Pick tournament to declare results
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 90.dp)
      ) {
        item {
          Text(
            text = "SELECT MATCH TO DECLARE RESULTS & DISTRIBUTE PRIZES",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(10.dp))
        }

        if (activeTournaments.isEmpty()) {
          item {
            Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
              Text("No active matches found", color = TextMuted)
            }
          }
        } else {
          items(activeTournaments) { tourn ->
            Card(
              onClick = { selectedTournament = tourn },
              colors = CardDefaults.cardColors(containerColor = CarbonCard),
              border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .testTag("result_pick_${tourn.id}")
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(text = tourn.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                  Text(text = "Prize Pool: ₹${tourn.totalPrizePool.toInt()} • Status: ${tourn.status.displayName}", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
                }

                Button(
                  onClick = { selectedTournament = tourn },
                  colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
                  shape = RoundedCornerShape(8.dp),
                  contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                  Text("Enter Results", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }
    } else {
      // Results Entry Form for Selected Match
      val tourn = selectedTournament!!
      val registrationsFlow = viewModel.repository.getRegistrationsForTournament(tourn.id)
      val registrations by registrationsFlow.collectAsState(initial = emptyList())

      ResultsEntryView(
        tournament = tourn,
        registrations = registrations,
        onBack = { selectedTournament = null },
        onSubmitPrizes = { updatedList ->
          viewModel.distributePrizes(tourn.id, updatedList) {
            Toast.makeText(context, "Prizes successfully distributed into player wallets!", Toast.LENGTH_LONG).show()
            selectedTournament = null
          }
        }
      )
    }
  }
}

@Composable
fun ResultsEntryView(
  tournament: Tournament,
  registrations: List<Registration>,
  onBack: () -> Unit,
  onSubmitPrizes: (List<Registration>) -> Unit
) {
  // Local state for placement and kills per registration
  val ranks = remember(registrations) {
    mutableStateListOf<Int>().apply {
      registrations.forEachIndexed { index, reg ->
        add(if (reg.placementRank > 0) reg.placementRank else index + 1)
      }
    }
  }

  val kills = remember(registrations) {
    mutableStateListOf<Int>().apply {
      registrations.forEach { reg ->
        add(reg.kills)
      }
    }
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 90.dp)
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "MATCH RESULTS & PRIZES", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = TextPrimary)
          Text(text = tournament.title, style = MaterialTheme.typography.bodySmall, color = NeonCyan)
        }

        Button(
          onClick = onBack,
          colors = ButtonDefaults.buttonColors(containerColor = CarbonCardElevated),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text("← Back", color = TextSecondary, fontSize = 12.sp)
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Prize Pool Rules Card
      Card(
        colors = CardDefaults.cardColors(containerColor = CarbonCard),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(text = "1st: ₹${tournament.firstPrize.toInt()}", color = EmeraldNeon, fontWeight = FontWeight.Bold, fontSize = 12.sp)
          Text(text = "2nd: ₹${tournament.secondPrize.toInt()}", color = AmberGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
          Text(text = "3rd: ₹${tournament.thirdPrize.toInt()}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
          Text(text = "Kill: ₹${tournament.perKillBonus.toInt()}", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
      }

      Spacer(modifier = Modifier.height(14.dp))
      Text(text = "PARTICIPATING TEAMS (${registrations.size})", style = MaterialTheme.typography.labelSmall, color = TextMuted)
      Spacer(modifier = Modifier.height(8.dp))
    }

    if (registrations.isEmpty()) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = CarbonCard),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "No players registered in this match yet to distribute prizes.",
            modifier = Modifier.padding(20.dp),
            color = TextMuted
          )
        }
      }
    } else {
      items(registrations.size) { idx ->
        val reg = registrations[idx]
        val rank = ranks.getOrElse(idx) { 1 }
        val killCount = kills.getOrElse(idx) { 0 }

        // Calculate prize dynamically
        val placementPrize = when (rank) {
          1 -> tournament.firstPrize
          2 -> tournament.secondPrize
          3 -> tournament.thirdPrize
          else -> 0.0
        }
        val killPrize = killCount * tournament.perKillBonus
        val totalWin = placementPrize + killPrize

        Card(
          colors = CardDefaults.cardColors(containerColor = CarbonCard),
          border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(
              if (rank == 1) listOf(EmeraldDark, EmeraldNeon)
              else if (rank == 2) listOf(AmberGold, AmberGold)
              else listOf(CarbonBorder, CarbonBorder)
            )
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(text = reg.teamName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(text = "Captain: ${reg.playerIgn} (UID: ${reg.playerUid})", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
              }
              Text(
                text = "Prize: ₹${totalWin.toInt()}",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 16.sp,
                color = if (totalWin > 0) EmeraldNeon else TextMuted
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Inputs for Rank and Kills
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              OutlinedTextField(
                value = rank.toString(),
                onValueChange = {
                  val newRank = it.toIntOrNull() ?: 1
                  if (idx < ranks.size) ranks[idx] = newRank
                },
                label = { Text("Rank (#)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                singleLine = true,
                modifier = Modifier
                  .weight(1f)
                  .testTag("input_rank_$idx")
              )

              OutlinedTextField(
                value = killCount.toString(),
                onValueChange = {
                  val newKills = it.toIntOrNull() ?: 0
                  if (idx < kills.size) kills[idx] = newKills
                },
                label = { Text("Kills") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                singleLine = true,
                modifier = Modifier
                  .weight(1f)
                  .testTag("input_kills_$idx")
              )
            }
          }
        }
      }

      item {
        Spacer(modifier = Modifier.height(20.dp))
        Button(
          onClick = {
            val updatedRegistrations = registrations.mapIndexed { i, reg ->
              val r = ranks.getOrElse(i) { 1 }
              val k = kills.getOrElse(i) { 0 }
              val placement = when (r) {
                1 -> tournament.firstPrize
                2 -> tournament.secondPrize
                3 -> tournament.thirdPrize
                else -> 0.0
              }
              val won = placement + (k * tournament.perKillBonus)
              reg.copy(
                placementRank = r,
                kills = k,
                prizeWon = won
              )
            }
            onSubmitPrizes(updatedRegistrations)
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("btn_distribute_prizes_payout")
        ) {
          Icon(Icons.Default.EmojiEvents, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "1-CLICK DISTRIBUTE PRIZES & REFERRAL BONUSES", fontWeight = FontWeight.Black)
        }
      }
    }
  }
}
