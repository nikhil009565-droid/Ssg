package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.Tournament
import com.example.data.repository.TodamentRepository
import com.example.ui.components.TodamentHeader
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ReferScreen
import com.example.ui.screens.TournamentsScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.screens.admin.AdminSuiteScreen
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TodamentTheme
import com.example.ui.viewmodel.TodamentViewModel

enum class AppScreen(
  val label: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector
) {
  HOME("Home", Icons.Filled.Home, Icons.Outlined.Home),
  TOURNAMENTS("Scrims", Icons.Filled.SportsEsports, Icons.Outlined.SportsEsports),
  WALLET("Wallet", Icons.Filled.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet),
  REFER("Refer", Icons.Filled.CardGiftcard, Icons.Outlined.CardGiftcard),
  PROFILE("Profile", Icons.Filled.Person, Icons.Outlined.Person),
  ADMIN_SUITE("Admin", Icons.Filled.Person, Icons.Outlined.Person),
  AUTH("Auth", Icons.Filled.Person, Icons.Outlined.Person)
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      TodamentTheme {
        TodamentApp()
      }
    }
  }
}

@Composable
fun TodamentApp(
  viewModel: TodamentViewModel = viewModel()
) {
  val context = LocalContext.current
  val currentUser by viewModel.currentUser.collectAsState()
  val uiMessage by viewModel.uiMessage.collectAsState()
  val errorMessage by viewModel.errorMessage.collectAsState()

  var currentScreen by remember { mutableStateOf(AppScreen.HOME) }
  var selectedTournamentForDetail by remember { mutableStateOf<Tournament?>(null) }
  val snackbarHostState = remember { SnackbarHostState() }

  // Check if logged in
  val isLoggedIn = currentUser != null

  // Handle toasts/snackbars
  LaunchedEffect(uiMessage) {
    uiMessage?.let {
      snackbarHostState.showSnackbar(it)
      viewModel.clearMessages()
    }
  }

  LaunchedEffect(errorMessage) {
    errorMessage?.let {
      snackbarHostState.showSnackbar(it)
      viewModel.clearMessages()
    }
  }

  // Back Press Handling for secondary screens
  BackHandler(enabled = currentScreen != AppScreen.HOME) {
    if (currentScreen == AppScreen.ADMIN_SUITE) {
      currentScreen = AppScreen.PROFILE
    } else {
      currentScreen = AppScreen.HOME
    }
  }

  val isAdmin = currentUser?.isAdmin == true || currentUser?.email?.equals(TodamentRepository.SUPER_ADMIN_EMAIL, ignoreCase = true) == true

  if (!isLoggedIn) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
    ) {
      AuthScreen(
        viewModel = viewModel,
        onAuthSuccess = {
          currentScreen = AppScreen.HOME
        }
      )
    }
    return
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = CarbonBackground,
    topBar = {
      if (currentScreen != AppScreen.ADMIN_SUITE && currentScreen != AppScreen.AUTH) {
        Column(modifier = Modifier.statusBarsPadding()) {
          TodamentHeader(
            userName = currentUser?.fullName,
            userIgn = currentUser?.freeFireIgn,
            balance = currentUser?.walletBalance ?: 0.0,
            isAdmin = isAdmin,
            onWalletClick = { currentScreen = AppScreen.WALLET },
            onAdminClick = { currentScreen = AppScreen.ADMIN_SUITE }
          )
        }
      }
    },
    bottomBar = {
      if (currentScreen != AppScreen.ADMIN_SUITE && currentScreen != AppScreen.AUTH) {
        NavigationBar(
          containerColor = CarbonSurface,
          tonalElevation = 8.dp,
          modifier = Modifier
            .navigationBarsPadding()
            .border(width = 1.dp, color = CarbonBorder, shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .testTag("bottom_nav_bar")
        ) {
          val navItems = listOf(
            AppScreen.HOME,
            AppScreen.TOURNAMENTS,
            AppScreen.WALLET,
            AppScreen.REFER,
            AppScreen.PROFILE
          )

          navItems.forEach { screen ->
            val isSelected = currentScreen == screen
            NavigationBarItem(
              selected = isSelected,
              onClick = {
                currentScreen = screen
                if (screen != AppScreen.TOURNAMENTS) {
                  selectedTournamentForDetail = null
                }
              },
              icon = {
                Icon(
                  imageVector = if (isSelected) screen.selectedIcon else screen.unselectedIcon,
                  contentDescription = screen.label,
                  modifier = Modifier.size(22.dp)
                )
              },
              label = {
                Text(
                  text = screen.label,
                  fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
                  fontSize = 11.sp
                )
              },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CarbonBackground,
                selectedTextColor = EmeraldNeon,
                unselectedIconColor = TextSecondary,
                unselectedTextColor = TextMuted,
                indicatorColor = EmeraldNeon
              ),
              modifier = Modifier.testTag("nav_item_${screen.name.lowercase()}")
            )
          }
        }
      }
    },
    snackbarHost = {
      SnackbarHost(
        hostState = snackbarHostState,
        modifier = Modifier.padding(bottom = 80.dp)
      )
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (currentScreen) {
        AppScreen.HOME -> {
          HomeScreen(
            viewModel = viewModel,
            onNavigateToTournaments = { currentScreen = AppScreen.TOURNAMENTS },
            onNavigateToWallet = { currentScreen = AppScreen.WALLET },
            onNavigateToRefer = { currentScreen = AppScreen.REFER },
            onSelectTournament = { tourn ->
              selectedTournamentForDetail = tourn
              currentScreen = AppScreen.TOURNAMENTS
            }
          )
        }

        AppScreen.TOURNAMENTS -> {
          TournamentsScreen(
            viewModel = viewModel,
            onNavigateToWallet = { currentScreen = AppScreen.WALLET },
            selectedTournamentFromHome = selectedTournamentForDetail
          )
        }

        AppScreen.WALLET -> {
          WalletScreen(viewModel = viewModel)
        }

        AppScreen.REFER -> {
          ReferScreen(viewModel = viewModel)
        }

        AppScreen.PROFILE -> {
          ProfileScreen(
            viewModel = viewModel,
            onNavigateToAdmin = { currentScreen = AppScreen.ADMIN_SUITE },
            onNavigateToWallet = { currentScreen = AppScreen.WALLET },
            onLogout = { currentScreen = AppScreen.AUTH }
          )
        }

        AppScreen.ADMIN_SUITE -> {
          AdminSuiteScreen(
            viewModel = viewModel,
            onNavigateBack = { currentScreen = AppScreen.PROFILE }
          )
        }

        AppScreen.AUTH -> {
          AuthScreen(
            viewModel = viewModel,
            onAuthSuccess = { currentScreen = AppScreen.HOME }
          )
        }
      }
    }
  }
}
